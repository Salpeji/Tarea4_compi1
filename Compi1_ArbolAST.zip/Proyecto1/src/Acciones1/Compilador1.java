package Acciones1;
import Principal1.Lexico;
import Principal1.Nodo1;
import Principal1.sintactico;
import java.io.StringReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;
import Acciones1.Graficador1;

public class Compilador1{

    public void Analizar(String entrada, JTextPane consola)
    {
        try 
        {
            //crear el lexico
            Lexico lexico = new Lexico(new StringReader(entrada));
            //crear el sintactico
            sintactico parser = new sintactico(lexico);
            
            //ejecutar el analisis
            parser.parse();
                                    
            JOptionPane.showMessageDialog(null, "Analisis Completo","Ejemplo 1 AST",1);
            
            //Graficar
            //this.graficarAST(parser.raiz);            
            Graficador1 g = new Graficador1();
            g.graficarAST(parser.raiz);
            
            //Recorrido
            this.recorrido(parser.raiz, consola);
        } 
        catch (Exception ex) 
        {
            Logger.getLogger(Compilador1.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Ocurrio un grave problema","Ejemplo 1 AST",2);
        }        
    }
    
}