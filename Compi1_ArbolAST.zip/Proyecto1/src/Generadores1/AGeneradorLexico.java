package Generadores1;

import java.io.File;
import Principal1.Lexico;

public class AGeneradorLexico{
    public static void main (String []args ){
        String path = "src\\Principal1\\Lexico.jflex";
        generarLexer(path);
    }

    public static void generarLexer(String path){
        File a1 = new File(path);
        jflex.Main.generate(a1);
    }
}