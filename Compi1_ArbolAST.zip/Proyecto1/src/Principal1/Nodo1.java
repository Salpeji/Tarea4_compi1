package Principal1;
import java.util.ArrayList;

public class Nodo1{
    
    public String valor1;
    public int id1, linea1, columna1;
    public ArrayList<Nodo1> hijos1;
    
    public Nodo1(String val){
        this.valor1 = val;
        this.id1 = 0;
        this.linea1 = 0;
        this.columna1 = 0;
        this.hijos1 = new ArrayList<Nodo1>();
    }
    
    public Nodo1(String val, int lin, int col){
        this.valor1 = val;
        this.id1 = 0;
        this.linea1 = lin;
        this.columna1 = col;
        this.hijos1 = new ArrayList<Nodo1>();
    }   
}